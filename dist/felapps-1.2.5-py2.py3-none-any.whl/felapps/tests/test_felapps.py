#!/usr/bin/env python

import sys
sys.path.append('./felapps-1.0.0-py2.7.egg')
import felapps
felapps.imageviewer.run(maximize = True,logon = False)
#felapps.formula.run()
