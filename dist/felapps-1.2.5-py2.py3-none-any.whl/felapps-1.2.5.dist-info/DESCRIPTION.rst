FEL Apps (felapps) Python project
=================================

High-level application suite for free-electron laser, developed by Python

Author: Tong Zhang (zhangtong AT sinap dot ac dot cn)

first uploaded to github on Apr. 23, 2015

USAGE:

pip install felapps

type imageviewer in terminal to launch one of apps from felapps module

OR

import felapps

felapps.imageviewer.run()

if config.xml not found in present working directory, please choose right config.xml file as the app guiding.





