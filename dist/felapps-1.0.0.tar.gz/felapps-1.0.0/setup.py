#!/usr/bin/env python

"""FELApps project (felapps)"""

def readme():
    with open('README.rst') as f:
        return f.read()

from setuptools import find_packages, setup

appName             = "felapps"
appVersion          = "1.0.0"
appDescription      = "High-level applications for FEL commissioning."
appLong_description = "High-level applications created for the tunning/commissioning of the free-electron laser facilities."
appPlatform         = ["Linux"]
appAuthor           = "Tong Zhang"
appAuthor_email     = "zhangtong@sinap.ac.cn"
appLicense          = "MIT"
appKeywords         = "FEL high-level application physics commissioning"
requiredpackages = ['numpy','scipy','matplotlib', 'wx', 'pyepics'] # install_requires

setup(name             = appName,
      version          = appVersion,
      description      = appDescription,
      long_description = appLong_description,
      platforms        = appPlatform,
      author           = appAuthor,
      author_email     = appAuthor_email,
      license          = appLicense,
      keywords         = appKeywords,
      packages         = find_packages(exclude=['contrib','tests*']),
      install_requires = requiredpackages,
      )

