#!/usr/bin/env python

#---
#   test script for felapps
#   Tong Zhang, 2015-04-16
#---

import felapps
#felapps.dcls.run()
felapps.imageviewer.run()
