FEL Apps (felapps) Python project
=================================

High-level applications for the commissioning of free-electron laser (FEL)
facilities.

